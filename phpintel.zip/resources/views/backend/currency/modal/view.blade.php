<table class="table table-bordered">
	<tr><td>{{ _lang('Name') }}</td><td>{{ $currency->name }}</td></tr>
					<tr><td>{{ _lang('Exchange Rate') }}</td><td>{{ $currency->exchange_rate }}</td></tr>
					<tr><td>{{ _lang('Base Currency') }}</td><td>{{ $currency->base_currency }}</td></tr>
					<tr><td>{{ _lang('Status') }}</td><td>{{ $currency->status }}</td></tr>
</table>

