<table class="table table-bordered">
	<tr><td>{{ _lang('Title') }}</td><td>{{ $service->translation->title  }}</td></tr>
	<tr><td>{{ _lang('Content') }}</td><td>{{ $service->translation->body  }}</td></tr>
</table>

